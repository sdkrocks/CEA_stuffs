function removeElementsByClass(className) {
  const elements = document.getElementsByClassName(className);
  while (elements.length > 0) {
    elements[0].parentNode.removeChild(elements[0]);
  }
}

function remove() {
  removeElementsByClass("btn-common-play-game-lg");
  removeElementsByClass("place-btn");
  removeElementsByClass("chat-main");
  removeElementsByClass("interaction-container");

  try {
    document.getElementById("rbx-running-games").remove();
  } catch (error) {
    // skip
  }
  try {
    document.getElementById("recommended-games-container").remove();
  } catch (error) {
    // skip
  }

  // console.log("Join buttons removed.");
  setTimeout(function () {
    remove();
  }, 100);
}

var games = [
  {
    url: "https://www.roblox.com/games/183364845?privateServerLinkCode=01380491033975384772066114199249",
    title: "Speed Run 4",
    img: "https://tr.rbxcdn.com/6c450c9472829c1bd2f47406fcb2bff3/150/150/Image/Jpeg",
  },
  {
    url: "https://www.roblox.com/games/606849621?privateServerLinkCode=23581776701855100165147973572345",
    title: "Jailbreak",
    img: "https://tr.rbxcdn.com/f254d18363223ce9cc718ad645f1c372/150/150/Image/Jpeg",
  },
  {
    url: "https://www.roblox.com/games/734159876?privateServerLinkCode=83711062215364340552606740283345",
    title: "SharkBite",
    img: "https://tr.rbxcdn.com/ddd3005efcd5abe6240e23fcfdb77ec8/150/150/Image/Jpeg",
  },
  {
    url: "https://www.roblox.com/games/3527629287?privateServerLinkCode=WVZd0mwYlOLEfFCc41v9pCYjrXWG91uF",
    title: "Paintball",
    img: "https://tr.rbxcdn.com/bec64167dfc6fb135451f3ecaace04bb/150/150/Image/Jpeg",
  },
  {
    url: "https://www.roblox.com/games/1537690962?privateServerLinkCode=kyTX-ZLL-DcsnU7UDr-yIDYQjxzDs__U",
    title: "Bee Swarm Simulator",
    img: "https://tr.rbxcdn.com/e2b0e107193c917e2de281bbcb951487/150/150/Image/Jpeg",
  },
];

try {
  var gamesList = ``;
  games.forEach(function (game) {
    var html = `
    <div class="grid-item-container game-card-container" data-testid="game-tile">
      <a class="game-card-link" href="${game.url}">
        <span class="thumbnail-2d-container game-card-thumb-container"><img class="" src="${game.img}"></span>
        <div class="game-card-name game-name-title">${game.title}</div>
      </a>
    </div>`;
    gamesList = gamesList + html;
  });

  $("#HomeContainer").prepend(`
  <img style="margin-bottom: 20px;"src="https://static.wixstatic.com/media/a21be2_40fe0c8c7dd74210be0ab181c0096ab0~mv2.png/v1/fill/w_560,h_148,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/a21be2_40fe0c8c7dd74210be0ab181c0096ab0~mv2.png" />
  <br />
  <a href="https://web.roblox.com/users/18183899/profile"><button style="background-color: #00a2ff; margin-bottom:20px"><h2>Friend Slayde</h2></button></a>
  <div class="game-home-page-carousel-title"><a class="font-header-1">Quick Join</div>
  <br />
  <div data-testid="game-carousel" class="game-carousel">
  ${gamesList}
  </div>
  `);
} catch (error) {
  console.log(error);
}

// Add join button to games
games.forEach(function (game) {
  try {
    $(`
    <div>
      <button style="background-color:blue;" href="${game.url}"><h2>Join Slayde's server</h2></button>
    </div>
  `).insertAfter(`.game-title-container:contains(${game.title})`);
  } catch (error) {
    // Skip
  }
});

remove();
